clc; clear; close all;

%% 定义文件路径和频率列表
frequencies = [120, 140, 160, 220, 225, 229]; % 频率列表（单位：GHz）
wave_conditions = {'Big Wave', 'Little Wave', 'No Wave'}; % 波浪条件列表
num_wave = length(wave_conditions);
num_freq = length(frequencies);

%% 初始化存储数组
total_loss_mean = zeros(num_freq, num_wave); % 平均损耗矩阵
e = zeros(num_freq, num_wave);              % 标准误差矩阵
LoS_values = zeros(num_freq, num_wave);
%% 循环读取所有文件数据
for condIdx = 1:num_wave
    for freqIdx = 1:num_freq
        % 动态生成文件名NLOS 160GHzNo Wave
        fileName = sprintf('NLOS %dGHz%s.xlsx', frequencies(freqIdx), wave_conditions{condIdx});
        filePath = fullfile(pwd, 'data', fileName);
        
        % 读取数据（假设数据格式一致）
        % 读取整列数据（从 F1 开始）
        full_column = readmatrix(filePath, 'Range', 'F:F');

        % 剔除第一个元素（即 F2 的数据）
        data = full_column(2:end);
        
        % 计算统计量
        total_loss_mean(freqIdx, condIdx) = mean(data);
        e(freqIdx, condIdx) = std(data)/sqrt(length(data));
    end
end

%% 计算波浪损耗（相对于无波浪情况）
%% 循环读取所有文件数据
for condIdx = 1:num_wave
    for freqIdx = 1:num_freq
        % 动态生成文件名LOS 160GHzNo Wave
        fileName = sprintf('LOS %dGHz%s.xlsx', frequencies(freqIdx), wave_conditions{condIdx});
        filePath = fullfile(pwd, 'data1', fileName);
        
        % 读取数据（假设数据格式一致）
        % 读取整列数据（从 F1 开始）
        full_column = readmatrix(filePath, 'Range', 'F:F');

        % 剔除第一个元素（即 F2 的数据）
        data1 = full_column(2:end);
        
        % 计算统计量
        LoS_values(freqIdx, condIdx) = mean(data1);
        e1(freqIdx, condIdx) = std(data1)/sqrt(length(data1));
    end
end

% 定义路径长度（单位：米）
d1 = 51;
d2 = 47.6545;
% 计算自由空间路径损耗（单位：dB）
% 公式：L = 20*log10(d) + 20*log10(f) + 32.44
% 其中，d 是路径长度（m），f 是频率（GHz）
FSPL = @(d, f) 20 * log10(d) + 20 * log10(f) + 32.44;
losses = zeros(length(frequencies), 1);
for j = 1:length(frequencies)
        f = frequencies(j);  % Frequency
        % Calculate FSPL for each configuration
        FSPL_LoS = FSPL(d1, f);
        FSPL_NLoS = FSPL(d2, f);
        losses(j,1) = FSPL_LoS - FSPL_NLoS;
end
% 计算两个路径长度下的损耗差值
wave_loss = total_loss_mean + losses - LoS_values; 
e2 = e - e1;
%% 绘图
figure;
hold on;

% 定义曲线样式
styles = {'-o', '-s', '-^'};
colors = {'b', 'r', 'g'};
legend_labels = {'Big Wave', 'Little Wave', 'no Wave'};

% 绘制有波浪的条件
for condIdx = 1:num_wave
    errorbar(frequencies,...
             wave_loss(:, condIdx),...
             e2(:, condIdx),...
             styles{condIdx},...
             'Color', colors{condIdx},...
             'MarkerSize', 2,...
             'LineWidth', 1.5,...
             'DisplayName', legend_labels{condIdx});
end
% 调整误差线的上下部分（垂直线）的粗细
h.LineWidth = 8;  % 主线条粗细
h.CapSize = 20;   % 误差线上下部分的长度
xlabel('Frequency (GHz)');
ylabel('Wave Loss (dB)');
title('Wave Loss Characterization at swimming pool');
legend('show');
grid on;
set(gca, 'FontSize', 12);
set(gcf, 'Position', [100, 100, 800, 600]);
hold off;