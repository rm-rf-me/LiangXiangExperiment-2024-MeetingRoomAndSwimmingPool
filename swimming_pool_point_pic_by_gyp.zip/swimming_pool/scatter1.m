clc; clear; close all;
% 读取Excel文件
nowave = readmatrix('no wave.xlsx');
bigwave = readmatrix('big wave.xlsx');
littlewave = readmatrix('little wave.xlsx');
frequency = [120,140,160,220,225,229];
LoS_nowave1 = [-28.2148018448622,-26.9593229441103,-26.6231463323308,-16.9359566473684,-18.2603528874687,-18.7865403403509];
LoS_littlewave1 = [-30.2842042508772,-29.8542879751880,-31.0310112496241,-16.9892438298246,-18.3152666295739,-18.8211854832080];
LoS_bigwave1 = [-35.5280205725714,-35.0958948345912,-34.6386819415000,-17.0270730090226,-18.3015303097744,-18.8735101355890];
% 扩展frequency以匹配每个数据的行数
[rows_nowave, cols] = size(nowave);
frequency_nowave = repmat(frequency, rows_nowave, 1); % 复制列以匹配nowave的列数
LoS_nowave = repmat(LoS_nowave1, rows_nowave, 1);
data_nowave = nowave(:) - LoS_nowave(:);

[rows_bigwave, ~] = size(bigwave);
frequency_bigwave = repmat(frequency, rows_bigwave, 1);
LoS_bigwave = repmat(LoS_bigwave1, rows_bigwave, 1);
data_bigwave = bigwave(:) - LoS_bigwave(:);

[rows_littlewave, ~] = size(littlewave);
frequency_littlewave = repmat(frequency, rows_littlewave, 1);
LoS_littlewave = repmat(LoS_littlewave1, rows_littlewave, 1);
data_littlewave = littlewave(:) - LoS_littlewave(:);

% 创建散点图并分开显示
figure;
scatter(frequency_nowave(:), data_nowave, 'r');
xlabel('Frequency');
ylabel('Loss(dB)');
title('No Wave Loss');
legend('No Wave');
grid on;
axis tight;

figure;
scatter(frequency_bigwave(:), data_bigwave, 'b');
xlabel('Frequency');
ylabel('Loss(dB)');
title('Big Wave Loss');
legend('Big Wave');
grid on;
axis tight;

figure;
scatter(frequency_littlewave(:), data_littlewave, 'g');
xlabel('Frequency');
ylabel('Loss(dB)');
title('Little Wave Loss');
legend('Little Wave');
grid on;
axis tight;

